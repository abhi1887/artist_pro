@include('Frontend.layouts.header')

@yield('content')

@include('Frontend.layouts.footer')
