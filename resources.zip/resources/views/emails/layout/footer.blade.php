    <table style="padding: 0; margin: 0; background-color: rgb(40,40,40); text-align: center; width: 100%; height: 100%; bottom: 0; text-align: center; align-items: center; ">
        <tr></tr>
    </table>