<nav class="navbar navbar-expand navbar-light bg-red topbar mb-4 static-top shadow">

    <img src="{{ asset('Frontend/images/artist_logo.png') }}" class="artist_logo">
    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>
</nav>
